const { onSchedule } = require('firebase-functions/v2/scheduler');
const { logger } = require('firebase-functions');
const { initializeApp } = require('firebase-admin/app');
const { getFirestore, FieldValue } = require('firebase-admin/firestore');
const { getMessaging } = require('firebase-admin/messaging');

initializeApp();
const db = getFirestore();
const fcm = getMessaging();

function validStart(value) {
  const ms = Date.parse(value || '');
  return Number.isFinite(ms) ? ms : null;
}

async function getContext() {
  const [staffSnap, tokenSnap] = await Promise.all([
    db.collection('staff').where('active', '==', true).get(),
    db.collection('push_tokens').where('active', '==', true).get()
  ]);
  const staff = new Map(staffSnap.docs.map(d => [d.id, { id:d.id, ...d.data() }]));
  const tokens = tokenSnap.docs.map(d => ({ id:d.id, ref:d.ref, ...d.data() })).filter(t => t.token && t.staff_id);
  return { staff, tokens };
}

async function sendToTokenDocs(tokenDocs, data) {
  if (!tokenDocs.length) return { successCount:0, failureCount:0 };
  const response = await fcm.sendEachForMulticast({
    tokens: tokenDocs.map(t => t.token),
    data: Object.fromEntries(Object.entries(data).map(([k,v]) => [k, String(v)])),
    webpush: { headers: { Urgency: 'high' } }
  });

  const cleanup = [];
  response.responses.forEach((r, i) => {
    if (!r.success) {
      const code = r.error?.code || '';
      if (code === 'messaging/registration-token-not-registered' || code === 'messaging/invalid-registration-token') {
        cleanup.push(tokenDocs[i].ref.delete());
      }
    }
  });
  if (cleanup.length) await Promise.allSettled(cleanup);
  return response;
}

exports.coverageAlerts = onSchedule({
  schedule: '* * * * *',
  timeZone: 'America/Asuncion',
  region: 'southamerica-east1',
  memory: '256MiB',
  timeoutSeconds: 60,
  retryCount: 0
}, async () => {
  const now = Date.now();
  const coursesSnap = await db.collection('courses').get();
  const { staff, tokens } = await getContext();
  const updates = [];

  for (const doc of coursesSnap.docs) {
    const c = doc.data();
    const start = validStart(c.start_at);
    if (start === null) continue;
    const minutesToStart = (start - now) / 60000;

    // 1) Aviso al Staff asignado 10 minutos antes.
    if (!c.reminder_10_sent_at && minutesToStart <= 10 && minutesToStart > 8) {
      let recipients = [];
      let title = 'Tu cobertura empieza en 10 minutos';
      let body = `${c.title} · ${c.location || 'Lugar sin definir'}`;

      if (c.assigned_staff_id) {
        recipients = tokens.filter(t => t.staff_id === c.assigned_staff_id);
      } else {
        recipients = tokens;
        title = '⚠️ Curso sin Staff asignado';
        body = `${c.title} empieza en 10 minutos y todavía no tiene responsable.`;
      }

      const result = await sendToTokenDocs(recipients, {
        title, body, tag:`reminder-${doc.id}`, url:'./', course_id:doc.id, kind:'10m'
      });
      if (result.successCount > 0) {
        updates.push(doc.ref.update({ reminder_10_sent_at:FieldValue.serverTimestamp(), updated_at:FieldValue.serverTimestamp() }));
      }
    }

    // 2) Al comenzar el curso, si nadie marcó inicio, avisar al resto del Staff.
    if (!c.uncovered_alert_sent_at && !c.check_start && now >= start && now < start + 10 * 60000) {
      const recipients = tokens.filter(t => !c.assigned_staff_id || t.staff_id !== c.assigned_staff_id);
      const result = await sendToTokenDocs(recipients, {
        title:'⚠️ Curso sin cubrir',
        body:`${c.title} ya comenzó y todavía no tiene el inicio de cobertura marcado.`,
        tag:`uncovered-${doc.id}`, url:'./', course_id:doc.id, kind:'uncovered'
      });
      if (result.successCount > 0) {
        updates.push(doc.ref.update({ uncovered_alert_sent_at:FieldValue.serverTimestamp(), updated_at:FieldValue.serverTimestamp() }));
      }
    }
  }

  if (updates.length) await Promise.allSettled(updates);
  logger.info('Cobertura ECT: ciclo de avisos completado', { courses:coursesSnap.size, updates:updates.length, staff:staff.size, tokens:tokens.length });
});
